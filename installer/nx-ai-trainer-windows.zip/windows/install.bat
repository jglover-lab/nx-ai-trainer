@echo off
setlocal

echo ================================================
echo  nx-ai-trainer Windows Installer
echo ================================================
echo.

:: Check for Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Install Python 3.9+ and add to PATH.
    pause
    exit /b 1
)

:: Get script directory (project root is two levels up)
set SCRIPT_DIR=%~dp0
set PROJECT_DIR=%SCRIPT_DIR%..\..\

:: Install Python dependencies
echo Installing Python dependencies...
pip install -r "%PROJECT_DIR%requirements.txt" --quiet
if errorlevel 1 (
    echo ERROR: Failed to install dependencies.
    pause
    exit /b 1
)

:: Optional: PyTorch for CNN / MobileNetV2 training methods
echo.
set /p INSTALL_TORCH="Install PyTorch for CNN/MobileNetV2 training? (Y/N): "
if /i "%INSTALL_TORCH%"=="Y" (
    echo Detecting GPU...
    nvidia-smi >nul 2>&1
    if not errorlevel 1 (
        echo NVIDIA GPU detected - installing CUDA 12.1 build...
        set TORCH_URL=https://download.pytorch.org/whl/cu121
    ) else (
        echo No NVIDIA GPU detected - installing CPU build...
        set TORCH_URL=https://download.pytorch.org/whl/cpu
    )
    pip install torch torchvision onnxscript --index-url %TORCH_URL% --quiet
    if errorlevel 1 (
        echo WARNING: PyTorch install failed. CNN/MobileNetV2 methods will not be available.
    ) else (
        echo PyTorch installed successfully.
    )
) else (
    echo Skipping PyTorch. Basic training method will still work.
)

:: Set target install path
set INSTALL_DIR=C:\ProgramData\nx-ai-trainer

echo Copying files to %INSTALL_DIR%...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%INSTALL_DIR%\web" mkdir "%INSTALL_DIR%\web"

xcopy /Y /Q "%PROJECT_DIR%server.py" "%INSTALL_DIR%\"
xcopy /Y /Q "%PROJECT_DIR%requirements.txt" "%INSTALL_DIR%\"
xcopy /Y /S /Q "%PROJECT_DIR%web\*" "%INSTALL_DIR%\web\"

:: Copy config only if it doesn't exist (don't overwrite user settings)
if not exist "%INSTALL_DIR%\config.json" (
    xcopy /Y /Q "%PROJECT_DIR%config.json" "%INSTALL_DIR%\"
    echo.
    echo IMPORTANT: Edit %INSTALL_DIR%\config.json with your Nx server credentials.
)

:: Look for NSSM
set NSSM=
if exist "C:\ProgramData\nx-sip-client\nssm.exe" set NSSM=C:\ProgramData\nx-sip-client\nssm.exe
if exist "C:\tools\nssm.exe" set NSSM=C:\tools\nssm.exe
for %%i in (nssm.exe) do set NSSM_PATH=%%~$PATH:i
if defined NSSM_PATH set NSSM=%NSSM_PATH%

if not defined NSSM (
    echo.
    echo NSSM not found. Skipping service installation.
    echo To install as a service manually:
    echo   nssm install NxAITrainer python "%INSTALL_DIR%\server.py"
    echo   nssm set NxAITrainer AppDirectory "%INSTALL_DIR%"
    echo   nssm start NxAITrainer
    goto :done
)

echo.
echo Installing Windows service via NSSM...

:: Resolve full Python path so NSSM can find it from LocalSystem account (minimal PATH)
set PYTHON_EXE=
for /f "delims=" %%i in ('where python 2^>nul') do if not defined PYTHON_EXE set PYTHON_EXE=%%i
if not defined PYTHON_EXE (
    echo ERROR: Cannot resolve full Python path. Install Python and ensure it is on PATH.
    pause
    exit /b 1
)
echo Using Python: %PYTHON_EXE%

set SVC_NAME=nx-ai-trainer

:: Remove old NxAITrainer service name if present (legacy)
"%NSSM%" status NxAITrainer >nul 2>&1
if not errorlevel 1 (
    echo Removing legacy NxAITrainer service...
    "%NSSM%" stop NxAITrainer confirm >nul 2>&1
    "%NSSM%" remove NxAITrainer confirm >nul 2>&1
)

:: Remove existing service if present
"%NSSM%" status %SVC_NAME% >nul 2>&1
if not errorlevel 1 (
    echo Removing existing %SVC_NAME% service...
    "%NSSM%" stop %SVC_NAME% confirm >nul 2>&1
    "%NSSM%" remove %SVC_NAME% confirm >nul 2>&1
)

"%NSSM%" install %SVC_NAME% "%PYTHON_EXE%" "%INSTALL_DIR%\server.py"
"%NSSM%" set %SVC_NAME% AppDirectory "%INSTALL_DIR%"
"%NSSM%" set %SVC_NAME% DisplayName "Nx AI Trainer"
"%NSSM%" set %SVC_NAME% Description "Train custom AI models from Nx camera streams and deploy to Nx AI Manager"
:: Delayed auto-start: waits until network is up before starting (avoids Nx connection failure at boot)
"%NSSM%" set %SVC_NAME% Start SERVICE_DELAYED_AUTO_START
"%NSSM%" set %SVC_NAME% AppStdout "%INSTALL_DIR%\service.log"
"%NSSM%" set %SVC_NAME% AppStderr "%INSTALL_DIR%\service.log"
"%NSSM%" set %SVC_NAME% AppRotateFiles 1
"%NSSM%" set %SVC_NAME% AppRotateBytes 1048576
:: Restart automatically if server.py crashes
"%NSSM%" set %SVC_NAME% AppExit Default Restart
"%NSSM%" set %SVC_NAME% AppRestartDelay 5000
"%NSSM%" start %SVC_NAME%

echo.
:done
echo ================================================
echo  Installation complete.
echo  Open http://localhost:8767 in your browser,
echo  or add it as a Web Page item in Nx Client.
echo ================================================
echo.
pause
